import os
import face_recognition
import cv2

# Directory containing the training images
train_dir = 'dataset/'

# Initialize lists to hold known face encodings and their names
known_face_encodings = []
known_face_names = []

# Load training images and learn how to recognize them
for person_name in os.listdir(train_dir):
    person_dir = os.path.join(train_dir, person_name)
    if os.path.isdir(person_dir):
        for image_name in os.listdir(person_dir):
            image_path = os.path.join(person_dir, image_name)
            image = face_recognition.load_image_file(image_path)
            face_encodings = face_recognition.face_encodings(image)
            if face_encodings:
                # Use the first face encoding found in the image (assuming one face per image)
                known_face_encodings.append(face_encodings[0])
                known_face_names.append(person_name)

# Function to detect and recognize faces in a new image
def detect_and_recognize_faces(image_path, output_dir):
    image = face_recognition.load_image_file(image_path)
    face_locations = face_recognition.face_locations(image)
    face_encodings = face_recognition.face_encodings(image, face_locations)

    # Convert the image to BGR for OpenCV
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

    # Iterate over each detected face
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        # Check if the face is a match for known faces
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
        name = "Unknown"

        # Use the known face with the smallest distance to the new face
        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        best_match_index = min(range(len(face_distances)), key=face_distances.__getitem__)
        if matches[best_match_index]:
            name = known_face_names[best_match_index]

        print(name)
        # Draw a box around the face and label it with a name
        cv2.rectangle(image, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.rectangle(image, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(image, name, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)

    # Save the image with the detected faces
    output_path = os.path.join(output_dir, os.path.basename(image_path))
    cv2.imwrite(output_path, image)

# Directory containing the images to be recognized
test_dir = 'test'
output_dir = 'output'

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Iterate over each image in the test directory and detect faces
for filename in os.listdir(test_dir):
    if filename.endswith('.jpg') or filename.endswith('.jpeg') or filename.endswith('.png'):
        image_path = os.path.join(test_dir, filename)
        detect_and_recognize_faces(image_path, output_dir)
